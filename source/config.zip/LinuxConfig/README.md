# LinuxConfig
新的Linux服务器（CentOS）的快速配置

# 用法
在当前目录下输入一下命令并回车

`
chmod +x *.sh
`


## 一、安装zsh

`
./toZsh.sh
`

## 二、安装oh my zsh

`
./configZsh.sh
`




